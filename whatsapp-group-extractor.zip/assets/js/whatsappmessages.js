// Array of messages for WhatsApp link
const whatsappMessages = [
    "Hi there! How can I assist you today?",
    "Hello! Need any help? I'm here for you.",
    "Hey! Can we chat? How can I support you?",
    "Greetings! Let me know how I can help you today.",
    "Hi! How are you doing? Feel free to ask me anything."
];
